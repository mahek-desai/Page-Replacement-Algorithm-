from flask import Flask, request, jsonify, render_template

app = Flask(__name__, static_folder="static", static_url_path="/")

def simulate_fifo(sequence, frame_size):
    frames = []
    output = []
    page_faults = []
    for page in sequence:
        if page not in frames:
            page_faults.append(True)
            if len(frames) >= frame_size:
                frames.pop(0)
            frames.append(page)
        else:
            page_faults.append(False)
        output.append(frames.copy())
    return output, page_faults

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/simulate", methods=["POST"])
def simulate():
    data = request.get_json()
    sequence = data["sequence"]
    frame_size = data["frameSize"]
    algorithm = data["algorithm"]
    
    result, page_faults = simulate_fifo(sequence, frame_size)
    
    return jsonify({"result": result, "page_faults": page_faults})

if __name__ == "__main__":
    app.run(debug=True)
